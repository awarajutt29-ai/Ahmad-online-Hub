AHMAD ONLINE HUB — PRO DEMO
==========================
Included:
- Responsive modern homepage
- Services section
- Free tools: calculator, word counter, password generator, age calculator, unit converter, percentage calculator
- Login/signup demo UI + dashboard
- Pricing section
- Affiliate/recommendation section
- Contact modal
- Mobile responsive layout

IMPORTANT:
Login/signup, payments, email/contact delivery, affiliate tracking and admin/database features are DEMOS in this static version. They require a real backend/service before accepting real accounts or payments.

To use:
1. Open index.html in a browser.
2. Upload it to a static hosting provider.
3. Replace demo text with your business details.
